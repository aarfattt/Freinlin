
export interface CollectionItem {
  id: string;
  title: string;
  category: string;
  image: string;
  description: string;
}

export interface NavItem {
  label: string;
  href: string;
}

export interface StoreTiming {
  days: string;
  hours: string;
}
