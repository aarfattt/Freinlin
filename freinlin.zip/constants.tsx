
import { CollectionItem, NavItem, StoreTiming } from './types';

export const BRAND_NAME = "Freinlin";
export const TAGLINE = "Royalty For Everyone";
export const ADDRESS = "Shop F1, Plot 44, Near Noor Hospital, Shivaji Nagar, Govandi, Mumbai, Maharashtra – 400043";
export const EMAIL = "freinlin24x7@gmail.com";
export const INSTAGRAM_URL = "https://www.instagram.com/freinlin/";
export const WHATSAPP_NUMBER = "+919876543210";

export const NAV_ITEMS: NavItem[] = [
  { label: "Home", href: "#home" },
  { label: "Collections", href: "#collections" },
  { label: "About", href: "#about" },
  { label: "Visit Us", href: "#visit" },
  { label: "Contact", href: "#contact" }
];

export const COLLECTIONS: CollectionItem[] = [
  {
    id: "1",
    title: "Heritage Sweatshirts",
    category: "Sweatshirts",
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=800",
    description: "Heavy-weight cotton blend with royal embroidery for ultimate comfort."
  },
  {
    id: "2",
    title: "Urban Flux Shirts",
    category: "Trending Shirts",
    image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&q=80&w=800",
    description: "Oversized silhouettes and trending patterns that redefine street royalty."
  },
  {
    id: "3",
    title: "Monarch Jackets",
    category: "Jackets",
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80&w=800",
    description: "Premium utility jackets designed for style and protection."
  },
  {
    id: "4",
    title: "Signature Tees",
    category: "T-Shirts",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&q=80&w=800",
    description: "Essential luxury basics crafted from pure Supima cotton."
  },
  {
    id: "5",
    title: "Royal Oversized",
    category: "Trending Shirts",
    image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&q=80&w=800",
    description: "Statement pieces for those who lead the pack in Mumbai's fashion scene."
  },
  {
    id: "6",
    title: "Velvet Hoodies",
    category: "Sweatshirts",
    image: "https://images.unsplash.com/photo-1578932750294-f5075e85f44a?auto=format&fit=crop&q=80&w=800",
    description: "A soft touch of royalty with modern minimalist branding."
  }
];

export const TIMINGS: StoreTiming[] = [
  { days: "Monday - Saturday", hours: "11:00 AM - 10:00 PM" },
  { days: "Sunday", hours: "12:00 PM - 09:00 PM" }
];
