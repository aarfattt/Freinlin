
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  NAV_ITEMS, 
  BRAND_NAME, 
  TAGLINE, 
  COLLECTIONS, 
  TIMINGS, 
  ADDRESS, 
  EMAIL, 
  INSTAGRAM_URL, 
  WHATSAPP_NUMBER 
} from './constants';

const fadeUpVariant = {
  hidden: { opacity: 0, y: 40 },
  visible: { 
    opacity: 1, 
    y: 0, 
    transition: { duration: 0.8, ease: [0.21, 0.45, 0.32, 0.9] } 
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15
    }
  }
};

const App: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isVisitModalOpen, setIsVisitModalOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="relative overflow-x-hidden bg-black selection:bg-gold selection:text-black">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-black/95 backdrop-blur-md py-4 shadow-2xl border-b border-white/5' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <a href="#home" className="flex items-center space-x-2">
            <span className="text-2xl md:text-3xl font-serif font-bold tracking-widest text-gold uppercase">{BRAND_NAME}</span>
          </a>
          
          <div className="hidden md:flex space-x-8">
            {NAV_ITEMS.map((item) => (
              <a 
                key={item.href} 
                href={item.href} 
                className="text-xs uppercase tracking-[0.25em] hover:text-gold transition-colors duration-200 font-semibold"
              >
                {item.label}
              </a>
            ))}
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-gold focus:outline-none p-2">
              <i className={`fa-solid ${isMobileMenuOpen ? 'fa-xmark' : 'fa-bars'} text-2xl`}></i>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[60] bg-black flex flex-col items-center justify-center space-y-8"
          >
            {NAV_ITEMS.map((item) => (
              <a 
                key={item.href} 
                href={item.href} 
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-2xl font-serif text-gold uppercase tracking-widest"
              >
                {item.label}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Visit Store Modal */}
      <AnimatePresence>
        {isVisitModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-zinc-900 w-full max-w-4xl max-h-[90vh] overflow-y-auto relative rounded-sm shadow-2xl border border-white/10"
            >
              <button 
                onClick={() => setIsVisitModalOpen(false)}
                className="absolute top-4 right-4 z-10 text-white/50 hover:text-gold transition-colors text-2xl"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
              
              <div className="p-8 md:p-12">
                <h2 className="text-gold text-sm uppercase tracking-[0.4em] mb-4">Visit Our Store</h2>
                <h3 className="text-3xl md:text-5xl font-serif font-bold mb-8">Freinlin Showroom</h3>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-gold uppercase tracking-widest text-xs mb-2">Location</h4>
                      <p className="text-gray-300 leading-relaxed text-lg">{ADDRESS}</p>
                    </div>
                    <div>
                      <h4 className="text-gold uppercase tracking-widest text-xs mb-2">Store Hours</h4>
                      <div className="space-y-2">
                        {TIMINGS.map((t, i) => (
                          <div key={i} className="flex justify-between text-gray-400 text-sm">
                            <span>{t.days}</span>
                            <span>{t.hours}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="pt-4">
                      <a 
                        href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(ADDRESS)}`} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-3 text-gold group"
                      >
                        <span className="uppercase tracking-widest text-sm font-bold border-b border-gold/50 group-hover:border-gold transition-all">Open in Google Maps</span>
                        <i className="fa-solid fa-arrow-up-right-from-square text-xs"></i>
                      </a>
                    </div>
                  </div>
                  <div className="h-64 md:h-full min-h-[300px] rounded overflow-hidden border border-white/5">
                    <iframe 
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3771.3262371900135!2d72.9234839!3d19.0494056!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c672b1d03541%3A0xc3f8e5860b7e45e4!2sNoor%20Hospital!5e0!3m2!1sen!2sin!4v1715421234567!5m2!1sen!2sin" 
                      width="100%" 
                      height="100%" 
                      style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) brightness(0.8)' }} 
                      allowFullScreen={true} 
                      loading="lazy" 
                    ></iframe>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="home" className="relative h-screen w-full flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?auto=format&fit=crop&q=80&w=2000" 
            alt="Luxury Clothing" 
            className="w-full h-full object-cover opacity-40 grayscale hover:grayscale-0 transition-all duration-1000 scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-black"></div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 text-center px-6"
        >
          <motion.h2 
            initial={{ opacity: 0, letterSpacing: '0.2em' }}
            animate={{ opacity: 1, letterSpacing: '0.6em' }}
            transition={{ delay: 0.5, duration: 1 }}
            className="text-gold text-xs md:text-sm tracking-[0.6em] uppercase mb-8 font-medium"
          >
            Mumbai Fashion Elite
          </motion.h2>
          <h1 className="text-6xl md:text-9xl font-serif font-bold mb-8 tracking-tighter leading-[0.9]">
            {BRAND_NAME}<br/>
            <span className="text-xl md:text-3xl italic font-light tracking-[0.2em] text-gray-400 mt-4 block">{TAGLINE}</span>
          </h1>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
            className="flex flex-col md:flex-row items-center justify-center gap-6 mt-12"
          >
            <button 
              onClick={() => setIsVisitModalOpen(true)} 
              className="group relative px-12 py-5 bg-gold-gradient text-black font-bold uppercase tracking-[0.2em] text-xs hover:scale-105 transition-all duration-300 overflow-hidden"
            >
              <span className="relative z-10">Visit Store</span>
              <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
            </button>
            <a href="#collections" className="px-12 py-5 border border-gold/30 text-gold font-bold uppercase tracking-[0.2em] text-xs hover:bg-gold/5 hover:border-gold transition-all duration-300">
              The Collections
            </a>
          </motion.div>
        </motion.div>

        <div className="absolute bottom-12 left-1/2 -translate-x-1/2">
          <motion.div 
            animate={{ y: [0, 10, 0] }} 
            transition={{ repeat: Infinity, duration: 2 }}
            className="text-gold/30"
          >
            <i className="fa-solid fa-chevron-down text-xl"></i>
          </motion.div>
        </div>
      </section>

      {/* Featured Collection Section */}
      <section id="collections" className="py-32 bg-[#050505] px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            variants={fadeUpVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="flex flex-col lg:flex-row justify-between items-start lg:items-end mb-24 gap-12"
          >
            <div className="max-w-2xl">
              <h2 className="text-gold text-xs uppercase tracking-[0.5em] mb-6 font-semibold">Seasonal Drop</h2>
              <h3 className="text-4xl md:text-7xl font-serif font-bold leading-[1.1] mb-6">Redefining Urban Royalty.</h3>
              <p className="text-gray-500 text-lg md:text-xl font-light leading-relaxed">
                Discover our latest curation of streetwear and luxury essentials, handcrafted for those who demand excellence.
              </p>
            </div>
            <div className="flex gap-4">
              <div className="w-12 h-[1px] bg-gold self-center"></div>
              <span className="text-gold text-xs uppercase tracking-widest font-bold">Mumbai Collection 24'</span>
            </div>
          </motion.div>

          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12"
          >
            {COLLECTIONS.map((item) => (
              <motion.div 
                key={item.id}
                variants={fadeUpVariant}
                className="group relative cursor-pointer"
              >
                <div className="relative aspect-[4/5] overflow-hidden mb-8 border border-white/5 bg-zinc-900">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-1000 ease-out"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-transparent transition-colors duration-500"></div>
                  
                  {/* Badge */}
                  <div className="absolute top-6 right-6 px-4 py-1 bg-black/60 backdrop-blur-md border border-white/10 text-[10px] uppercase tracking-[0.3em] text-gold font-bold">
                    {item.category}
                  </div>

                  <div className="absolute bottom-0 left-0 w-full p-10 translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500 bg-gradient-to-t from-black via-black/80 to-transparent">
                    <p className="text-sm font-light leading-relaxed text-gray-300 italic mb-4">"{item.description}"</p>
                    <button className="text-xs uppercase tracking-[0.3em] text-gold border-b border-gold/40 hover:border-gold transition-all pb-1 font-bold">View In Store</button>
                  </div>
                </div>
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-2xl font-serif font-medium group-hover:text-gold transition-colors mb-1">{item.title}</h4>
                    <p className="text-[10px] uppercase tracking-[0.4em] text-gray-500 font-bold">{item.category}</p>
                  </div>
                  <div className="text-gold/20 group-hover:text-gold transition-colors text-2xl">
                    <i className="fa-solid fa-arrow-right-long -rotate-45 group-hover:rotate-0 transition-transform duration-500"></i>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about" className="py-32 bg-zinc-900 overflow-hidden relative">
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-[500px] h-[500px] bg-gold/5 rounded-full blur-[120px]"></div>
        
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.2 }}
            className="relative"
          >
            <div className="absolute -top-12 -left-12 w-32 h-32 border-t border-l border-gold/40"></div>
            <img 
              src="https://images.unsplash.com/photo-1576188973526-0e5d74221d5f?auto=format&fit=crop&q=80&w=1000" 
              alt="Store Interior" 
              className="w-full rounded-sm shadow-2xl grayscale hover:grayscale-0 transition-all duration-1000 relative z-10"
            />
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-gold/10 -z-0 blur-3xl"></div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, delay: 0.2 }}
            className="space-y-10"
          >
            <h2 className="text-gold text-xs uppercase tracking-[0.6em] font-bold">The Brand</h2>
            <h3 className="text-5xl md:text-7xl font-serif font-bold leading-tight tracking-tight">Elegance Without Compromise.</h3>
            <p className="text-gray-400 text-lg leading-relaxed font-light">
              Freinlin isn't just a label; it's a movement born in the vibrant streets of Mumbai. We bridge the gap between unattainable luxury and everyday streetwear.
            </p>
            <p className="text-gray-500 leading-relaxed italic border-l-2 border-gold/30 pl-6">
              "We meticulously source the finest fabrics to ensure that every garment bearing the Freinlin name feels like a second skin of royalty."
            </p>
            <div className="grid grid-cols-2 gap-12 pt-8">
              <div className="group cursor-default">
                <span className="text-4xl font-serif text-gold block mb-2 group-hover:translate-x-1 transition-transform">Premium</span>
                <span className="text-[10px] uppercase tracking-[0.3em] text-gray-500 font-bold">Mumbai Craftsmanship</span>
              </div>
              <div className="group cursor-default">
                <span className="text-4xl font-serif text-gold block mb-2 group-hover:translate-x-1 transition-transform">Accessible</span>
                <span className="text-[10px] uppercase tracking-[0.3em] text-gray-500 font-bold">Luxury For All</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Visit Us Section (Inline) */}
      <section id="visit" className="py-32 bg-black">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div 
            variants={fadeUpVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="text-center mb-24"
          >
            <h2 className="text-gold text-xs uppercase tracking-[0.6em] mb-6 font-bold">Our Store</h2>
            <h3 className="text-4xl md:text-7xl font-serif font-bold tracking-tight">Experience The Royalty</h3>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
             <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="space-y-12"
            >
              <div className="p-10 bg-zinc-900 border-l border-gold shadow-2xl relative group overflow-hidden">
                <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-20 transition-opacity">
                  <i className="fa-solid fa-map-location text-9xl"></i>
                </div>
                <h4 className="text-2xl font-serif mb-6 text-gold">Location & Contact</h4>
                <p className="text-gray-400 font-light leading-relaxed text-lg mb-8">
                  {ADDRESS}
                </p>
                <div className="flex flex-col gap-4">
                  <a href={`mailto:${EMAIL}`} className="text-gray-500 hover:text-gold transition-colors flex items-center gap-3">
                    <i className="fa-solid fa-envelope text-gold"></i>
                    <span className="text-sm">{EMAIL}</span>
                  </a>
                </div>
              </div>

              <div className="p-10 bg-zinc-900 border-l border-white/10 shadow-2xl">
                <h4 className="text-2xl font-serif mb-6">Opening Hours</h4>
                <div className="space-y-4">
                  {TIMINGS.map((t, i) => (
                    <div key={i} className="flex justify-between items-center border-b border-white/5 pb-4">
                      <span className="text-gray-400 font-medium">{t.days}</span>
                      <span className="text-gold font-bold text-sm tracking-widest">{t.hours}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <button 
                onClick={() => setIsVisitModalOpen(true)}
                className="w-full py-6 border border-gold/30 text-gold uppercase tracking-[0.4em] font-bold text-xs hover:bg-gold hover:text-black transition-all"
              >
                View Full Map & Info
              </button>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1 }}
              className="rounded overflow-hidden border border-white/10 h-[600px] shadow-2xl"
            >
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3771.3262371900135!2d72.9234839!3d19.0494056!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c672b1d03541%3A0xc3f8e5860b7e45e4!2sNoor%20Hospital!5e0!3m2!1sen!2sin!4v1715421234567!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) brightness(0.7) contrast(1.2)' }} 
                allowFullScreen={true} 
                loading="lazy" 
              ></iframe>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Instagram Feed Section */}
      <section className="py-32 bg-zinc-900">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div 
            variants={fadeUpVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="flex flex-col md:flex-row justify-between items-center mb-20 gap-8"
          >
            <div className="text-center md:text-left">
              <h2 className="text-5xl font-serif font-bold tracking-tight">Stay Royal</h2>
              <p className="text-gray-500 mt-4 text-lg">Join the 10k+ followers who choose Freinlin daily.</p>
            </div>
            <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" className="px-12 py-4 border border-gold text-gold hover:bg-gold hover:text-black transition-all font-bold uppercase tracking-widest text-xs">
              @Freinlin
            </a>
          </motion.div>
          
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6"
          >
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <motion.a 
                key={i} 
                variants={fadeUpVariant}
                href={INSTAGRAM_URL} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="block relative aspect-square overflow-hidden group shadow-lg border border-white/5"
              >
                <img 
                  src={`https://picsum.photos/seed/fashion_freinlin_${i}/600/600`} 
                  alt="Social Post" 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700"
                />
                <div className="absolute inset-0 bg-gold/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <i className="fa-brands fa-instagram text-white text-4xl"></i>
                </div>
              </motion.a>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 bg-black">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <motion.div
            variants={fadeUpVariant}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <h2 className="text-gold text-xs uppercase tracking-[0.6em] mb-8 font-bold">Connect</h2>
            <h3 className="text-4xl md:text-7xl font-serif font-bold mb-20 tracking-tight">Ready For Your Upgrade?</h3>
          </motion.div>
          
          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-10"
          >
            <motion.a 
              variants={fadeUpVariant}
              href={`mailto:${EMAIL}`} 
              className="p-12 bg-zinc-900 group hover:bg-gold transition-all duration-500 shadow-2xl relative overflow-hidden"
            >
              <i className="fa-solid fa-envelope text-4xl text-gold group-hover:text-black mb-6 transition-colors"></i>
              <h4 className="text-xl font-serif mb-3 group-hover:text-black transition-colors">Digital Concierge</h4>
              <p className="text-gray-500 text-xs tracking-widest uppercase group-hover:text-black/60 transition-colors">Write to us</p>
            </motion.a>
            
            <motion.a 
              variants={fadeUpVariant}
              href={`https://wa.me/${WHATSAPP_NUMBER}`} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-12 bg-zinc-900 group hover:bg-[#25D366] transition-all duration-500 shadow-2xl relative overflow-hidden"
            >
              <i className="fa-brands fa-whatsapp text-4xl text-gold group-hover:text-white mb-6 transition-colors"></i>
              <h4 className="text-xl font-serif mb-3 group-hover:text-white transition-colors">Direct WhatsApp</h4>
              <p className="text-gray-500 text-xs tracking-widest uppercase group-hover:text-white/60 transition-colors">Instant Chat</p>
            </motion.a>
            
            <motion.a 
              variants={fadeUpVariant}
              href={INSTAGRAM_URL} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-12 bg-zinc-900 group hover:bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600 transition-all duration-500 shadow-2xl relative overflow-hidden"
            >
              <i className="fa-brands fa-instagram text-4xl text-gold group-hover:text-white mb-6 transition-colors"></i>
              <h4 className="text-xl font-serif mb-3 group-hover:text-white transition-colors">Live Showcase</h4>
              <p className="text-gray-500 text-xs tracking-widest uppercase group-hover:text-white/60 transition-colors">Follow Trends</p>
            </motion.a>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 bg-[#050505] border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="text-center md:text-left">
            <h5 className="text-3xl font-serif font-bold tracking-widest text-gold mb-3 uppercase">{BRAND_NAME}</h5>
            <p className="text-gray-600 text-xs tracking-[0.4em] font-medium uppercase">{TAGLINE}</p>
          </div>
          
          <div className="flex space-x-10">
            <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-gold transition-colors text-xl"><i className="fa-brands fa-instagram"></i></a>
            <a href="#" className="text-gray-500 hover:text-gold transition-colors text-xl"><i className="fa-brands fa-facebook-f"></i></a>
            <a href="#" className="text-gray-500 hover:text-gold transition-colors text-xl"><i className="fa-brands fa-x-twitter"></i></a>
          </div>
          
          <div className="text-gray-700 text-[10px] uppercase tracking-[0.5em] font-bold">
            &copy; {new Date().getFullYear()} Freinlin Mumbai.
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <motion.a 
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 2.5, type: "spring", stiffness: 200 }}
        href={`https://wa.me/${WHATSAPP_NUMBER}`} 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-10 right-10 z-[80] w-16 h-16 bg-[#25D366] rounded-full flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all"
      >
        <i className="fa-brands fa-whatsapp text-white text-3xl"></i>
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full animate-ping"></span>
      </motion.a>
    </div>
  );
};

export default App;
